import axios from './myjs'

export function request(url, data = {}, method = '')