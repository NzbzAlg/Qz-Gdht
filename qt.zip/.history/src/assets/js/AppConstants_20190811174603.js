export const PARAM_SIGN_NAME = 'sign'
export const SIGN_SECURITY_KEY = 'qzbdata'	            // 参数签名密钥