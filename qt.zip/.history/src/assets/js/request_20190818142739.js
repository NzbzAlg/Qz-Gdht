import request from './myjs'

export function get