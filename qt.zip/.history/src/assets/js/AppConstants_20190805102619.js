export const PARAM_SIGN_NAME = 'sign'
export const SIGN_SECURITY_KEY = 'ors2017'	            // 参数签名密钥