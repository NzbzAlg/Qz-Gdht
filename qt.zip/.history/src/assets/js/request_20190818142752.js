import axios from './myjs'

export function getData()